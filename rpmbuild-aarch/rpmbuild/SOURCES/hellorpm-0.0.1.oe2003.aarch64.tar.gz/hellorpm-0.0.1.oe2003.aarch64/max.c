/*************************************************************************
    > File Name: max.c
    > Author: chaofei
    > Mail: chaofeibest@163.com 
    > Created Time: 2019-03-17 04:25:59
 ************************************************************************/

#include <stdio.h>
int max(int a, int b) {
  return a > b ? a : b;
}
